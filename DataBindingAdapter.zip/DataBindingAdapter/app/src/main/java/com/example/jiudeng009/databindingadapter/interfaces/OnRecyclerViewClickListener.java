package com.example.jiudeng009.databindingadapter.interfaces;

/**
 * Created by wang
 * on 2016/11/11
 */

public interface OnRecyclerViewClickListener {

    void onClick(int viewType, int position, Object data);

}
