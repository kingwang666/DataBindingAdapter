package com.wang.baseadapter.util;

public interface SwipeAdapterInterface {

    void notifyDatasetChanged();

}
