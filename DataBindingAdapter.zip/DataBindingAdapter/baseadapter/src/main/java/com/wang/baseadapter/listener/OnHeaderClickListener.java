package com.wang.baseadapter.listener;

/**
 * Created by wang
 * on 2016/11/11
 */

public interface OnHeaderClickListener {
    void onHeader(int viewType, int position);
}
