package com.wang.baseadapter.listener;


import com.wang.baseadapter.widget.SwipeItemView;

public class SimpleSwipeListener implements SwipeItemView.SwipeListener {

    @Override
    public void onStartOpen(SwipeItemView layout) {
    }

    @Override
    public void onOpen(SwipeItemView layout) {
    }

    @Override
    public void onStartClose(SwipeItemView layout) {
    }

    @Override
    public void onClose(SwipeItemView layout) {
    }

}
